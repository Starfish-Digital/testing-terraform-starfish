import { CloudWatchClient, PutMetricAlarmCommand, DeleteAlarmsCommand, DescribeAlarmsCommand } from "@aws-sdk/client-cloudwatch";
import { EC2Client, DescribeInstancesCommand } from "@aws-sdk/client-ec2";

// Create CloudWatch service object
const cw = new CloudWatchClient({ region: 'ap-southeast-1' });

// Create EC2 service object
const ec2 = new EC2Client({ region: 'ap-southeast-1' });

export const handler = async (event) => {

  const instId = event.detail.EC2InstanceId;
  const dimensions = [
    {
      Name: 'InstanceId',
      Value: instId
    }
  ];

  // Describe the EC2 instance
  const describeEC2Cmd = new DescribeInstancesCommand({ InstanceIds: [instId] });
  const describeEC2Instances = await ec2.send(describeEC2Cmd);

  const instance = describeEC2Instances.Reservations[0].Instances[0];
  const instanceType = instance.InstanceType;
  const imageId = instance.ImageId;

  if (event['detail-type'] === "EC2 Instance Launch Successful") {
    // Define alarm configurations for disk usage percentage
    const diskAlarmConfig = {
      AlarmName: `qa-ec2-instance(${instId})-disk-usage-alarm`,
      MetricName: 'disk_used_percent',
      Namespace: 'CWAgent',
      ComparisonOperator: 'GreaterThanOrEqualToThreshold',
      Threshold: 70,
      Period: 300,
      EvaluationPeriods: 1,
      Statistic: 'Average',
      Dimensions: [
        { Name: "path", Value: "/" },
        { Name: 'InstanceId', Value: instId },
        { Name: "AutoScalingGroupName", Value: event.detail.AutoScalingGroupName },
        { Name: "ImageId", Value: imageId },
        { Name: "InstanceType", Value: instanceType },
        { Name: "device", Value: "xvda1" },
        { Name: "fstype", Value: "xfs" }
      ],
      AlarmDescription: `Alarm when disk usage percentage for ${instId} exceeds 70%`,
      ActionsEnabled: true,
      AlarmActions: ["arn:aws:sns:ap-southeast-1:016057676206:qa-aws-alerts-topic"]
    };

    // Define alarm configurations for memory usage percentage
    const memoryAlarmConfig = {
      AlarmName: `qa-ec2-instance(${instId})-memory-usage-alarm`,
      MetricName: 'mem_used_percent',
      Namespace: 'CWAgent',
      ComparisonOperator: 'GreaterThanOrEqualToThreshold',
      EvaluationPeriods: 1,
      Period: 300,
      Statistic: 'Average',
      Threshold: 70,
      ActionsEnabled: true,
      AlarmActions: ["arn:aws:sns:ap-southeast-1:016057676206:qa-aws-alerts-topic"],
      AlarmDescription: `Alarm when server CPU for ${instId} exceeds 70%`,
      Dimensions: [
        { Name: 'InstanceId', Value: instId },
        { Name: "AutoScalingGroupName", Value: event.detail.AutoScalingGroupName },
        { Name: "InstanceType", Value: instanceType },
        { Name: "ImageId", Value: imageId }
      ],
      Unit: 'Percent'
    };

    // Create disk usage alarm
    const putDiskAlarmCmd = new PutMetricAlarmCommand(diskAlarmConfig);
    const createDiskAlarm = await cw.send(putDiskAlarmCmd);

    // Create memory usage alarm
    const putMemoryAlarmCmd = new PutMetricAlarmCommand(memoryAlarmConfig);
    const createMemoryAlarm = await cw.send(putMemoryAlarmCmd);

    return { createDiskAlarm, createMemoryAlarm };

  } else {
    // Delete alarms if event type is not 'EC2 Instance Launch Successful'
    const describeAlarmsCmd = new DescribeAlarmsCommand({});
    const describeAlarm = await cw.send(describeAlarmsCmd);

    // Filter alarms based on dimensions
    const filteredAlarms = describeAlarm.MetricAlarms.filter(alarm => {
      const alarmDimensions = alarm.Dimensions || [];
      return dimensions.every(dim => alarmDimensions.some(alarmDim => alarmDim.Name === dim.Name && alarmDim.Value === dim.Value));
    });

    // Extract alarm names
    const alarmNames = filteredAlarms.map(alarm => alarm.AlarmName);
    
    // Assuming `alarmNames` is an array of alarm names you wish to delete
if (alarmNames.length > 0) {
  const deleteParams = {
    AlarmNames: alarmNames
  };
  
  try {
    // Create a DeleteAlarmsCommand and send it using the CloudWatch client
    const deleteAlarmsCmd = new DeleteAlarmsCommand(deleteParams);
    const deleteAlarms = await cw.send(deleteAlarmsCmd);
    
    // console.log('Alarms deleted successfully:', deleteAlarms);
    return deleteAlarms;
    
  } catch (err) {
    console.error('Error deleting alarms:', err);
    throw err;
  }
  
} else {
  console.log('No alarms to delete.');
}

    return describeAlarm;
  }
};