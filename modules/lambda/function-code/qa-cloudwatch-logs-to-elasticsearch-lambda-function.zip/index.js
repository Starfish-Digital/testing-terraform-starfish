var http = require('http');
var zlib = require('zlib');

var ts = [ 0 ];
var DEBUG = false; // set to `true` to enable timestamps in results

var endpointHost = 'non-prod-elastic-internal-nlb-c4c84191442f0da3.elb.ap-southeast-1.amazonaws.com';
var endpointPort = 80;

var request_timeout = 800; // milliseconds

function debug(state) {
  if (DEBUG) { ts.push(state, Date.now() - ts[0]); }
}

exports.handler = function(input, context) {
  ts = [ Date.now() ];
  
  // decode input from base64
  var zippedInput = new Buffer.from(input.awslogs.data, 'base64');

  // decompress the input
  zlib.gunzip(zippedInput, function(error, buffer) {
      if (error) { context.fail(error); return; }

      // parse the input from JSON
      var awslogsData = JSON.parse(buffer.toString('utf8'));
      debug("parsed gzip");
      
      console.log(awslogsData);

      // transform the input to Elasticsearch documents
      var elasticsearchBulkData = transform(awslogsData);
      debug("transformed json");

      // skip control messages
      if (!elasticsearchBulkData) {
          context.succeed('Control message handled successfully '+JSON.stringify(ts));
          return;
      }

      // post documents to the Amazon Elasticsearch Service
      var requestParams = {
          host: endpointHost,
          port: endpointPort,
          method: 'POST',
          path: '/_bulk',
          body: elasticsearchBulkData,
          headers: {
              'Content-Type': 'application/json',
              'Authorization': 'Basic ZWxhc3RpYzpzdGFyZmlzaA==',
              'Host': endpointHost + ':' + endpointPort,
              'Content-Length': Buffer.byteLength(elasticsearchBulkData)
          }
      };
      
      console.log(requestParams);

      debug("sending request");
      var request = http.request(requestParams, function(response) {
        debug("started response");

        var responseBody = '';

        response.on('data', function(chunk) {
            responseBody += chunk;
        });

        response.on('end', function() {
          debug("finished response");

          var info = JSON.parse(responseBody);
          var failedItems;

          if (response.statusCode >= 200 && response.statusCode < 299) {
            failedItems = info.items.filter(function(x) {
              return x.index.status >= 300;
            });
          }

          var error = response.statusCode !== 200 || info.errors === true ? {
            "statusCode": response.statusCode,
            "responseBody": responseBody
          } : null;

          if (error) {
            console.log('Error: ' + JSON.stringify(error, null, 2));
            if (failedItems && failedItems.length > 0) {
                console.log("Failed Items: " + JSON.stringify(failedItems, null, 2));
            }
            context.fail(JSON.stringify([ error, ts ]));
          } else {
            context.succeed('Success '+JSON.stringify(ts));
          }
        });
      }).on('error', function(e) {
        context.fail(e);
      });

      request.on('socket', function(socket) {
        socket.setTimeout(request_timeout, function() {
          request.abort();
        });
        debug("socket established");
      });

      request.end(requestParams.body);
  });
};

function transform(payload) {
    if (payload.messageType === 'CONTROL_MESSAGE') {
        return null;
    }

    var bulkRequestBody = '';

    payload.logEvents.forEach(function(logEvent) {
        var timestamp = new Date(1 * logEvent.timestamp);

        // index name format: cwl-YYYY.MM.DD.HH
        var indexName = payload.logGroup.split('/').join('-').toLowerCase().replace(/^-/, '')+"-"+new Date().toISOString().split('T')[0];

        var source = {};
        source['@timestamp'] = timestamp.toISOString();
        source.message = logEvent.message;

        var action = { "index": {} };
        action.index._index = indexName;
        action.index._id = logEvent.id;

        bulkRequestBody += [
            JSON.stringify(action),
            JSON.stringify(source)
        ].join('\n') + '\n';
    });

    return bulkRequestBody;
}